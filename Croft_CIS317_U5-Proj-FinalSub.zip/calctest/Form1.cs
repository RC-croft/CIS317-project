﻿using System;
using System.IO;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace calctest
{
    public partial class Form1 : Form
    {
        string inpt = string.Empty;
        string opera = string.Empty;
        string memhist = string.Empty;
        double num1 = 0, num2 = 0, res;
        double memstore = 0.0;
        private LastValTest memtest= new LastValTest();
        
        public Form1()
        {
            InitializeComponent();
            Closing += Form1_Closing;

        }
        private void Form1_Closing(object sender, CancelEventArgs e) 
        { 
            if(double.TryParse(memstore.ToString(), out res)) 
            {
               
                var mem = new LastValMem {Res=res };
                memtest.Serialize(mem);
                
            }
            else { }
        }

        private void Form1_Load(object sender, EventArgs e)
        {
            if (File.Exists(memtest.FN))
            {
                var mem = memtest.Deserialize();
                In.Text = mem.Res.ToString();
            }
            else
            {
                var mem = new LastValMem{Res = res};
                In.Text = res.ToString();
                memtest.Serialize(mem);
            }
            if (In.Text != string.Empty) { num1 = Convert.ToDouble(In.Text); }
            else { In.Clear(); }
        }

        private void zero_Click(object sender, EventArgs e)
        {
            
            inpt += zero.Text;
            this.In.Text = In.Text + zero.Text;
            Console.WriteLine(inpt);
        }

        private void one_Click(object sender, EventArgs e)
        { 
            inpt += one.Text;
            this.In.Text = In.Text + one.Text;
            Console.WriteLine(inpt);
        }

        private void two_Click(object sender, EventArgs e)
        {
          
            inpt += two.Text;
            this.In.Text = In.Text + two.Text;
            Console.WriteLine(inpt);
        }

        private void three_Click(object sender, EventArgs e)
        {
         
            inpt += three.Text;
            this.In.Text = In.Text + three.Text;
            Console.WriteLine(inpt);
        }
        private void four_Click(object sender, EventArgs e)
        {
           
            inpt += four.Text;
            this.In.Text = In.Text + four.Text;
            Console.WriteLine(inpt);

        }

        private void five_Click(object sender, EventArgs e)
        {
          
            inpt += five.Text;
            this.In.Text = In.Text + five.Text;
            Console.WriteLine(inpt);
        }

        private void six_Click(object sender, EventArgs e)
        {
            
            inpt += six.Text;
            this.In.Text = In.Text + six.Text;
            Console.WriteLine(inpt);
        }

        private void seven_Click(object sender, EventArgs e)
        {
            
            inpt += seven.Text;
            this.In.Text = In.Text + seven.Text;
            Console.WriteLine(inpt);
        }

        private void eight_Click(object sender, EventArgs e)
        {
            
            inpt += eight.Text;
            this.In.Text = In.Text + eight.Text;

            Console.WriteLine(inpt);
        }

        private void nine_Click(object sender, EventArgs e)
        {
           
            inpt += nine.Text;
            this.In.Text = In.Text + nine.Text;
            Console.WriteLine(inpt);
        }

        private void Add_Click(object sender, EventArgs e)
        {
            num1 = Convert.ToDouble(In.Text);
            In.Clear();
            opera = Add.Text;
        }

        private void Subtract_Click(object sender, EventArgs e)
        {
            num1 = Convert.ToDouble(In.Text);
            In.Clear();
            opera = Subtract.Text;
        }

        private void Multiply_Click(object sender, EventArgs e)
        {
            num1 = Convert.ToDouble(In.Text);
            In.Clear();
            opera = Multiply.Text;
        }

        private void Divide_Click(object sender, EventArgs e)
        {
            num1 = Convert.ToDouble(In.Text);
            In.Clear();
            opera = Divide.Text;
        }

        private void period_Click(object sender, EventArgs e)
        {
            if (!In.Text.Contains("."))
            {
                inpt += period.Text;
                this.In.Text = In.Text + period.Text;
                Console.WriteLine(inpt);
            }
            else { MessageBox.Show("can only have 1 decimal place", 
                   "syntax error", MessageBoxButtons.OK, MessageBoxIcon.Error); }

        }

        

        private void Equal_Click(object sender, EventArgs e)
        {
            num2 = Convert.ToDouble(In.Text);
       
            
            if (opera != null)
            {
                string hist = "";
                switch (opera)
                {
                    case "+":

                        res = num1 + num2;
                        hist = (num1 + " + " + num2 + " = " + res);
                        History.Items.Add(hist);
                        memstore = res;
                        In.Clear();

                        break;
                    case "-":

                        res = num1 - num2;
                        
                        hist = (num1 + " - " + num2 + " = " + res);
                        History.Items.Add(hist);
                        memstore = res;
                        In.Clear();

                        break;
                    case "X":

                        res = num1 * num2;
                        
                        hist = (num1 + " X " + num2 + " = " + res);
                        History.Items.Add(hist);
                        memstore = res;
                        In.Clear();
                        break;
                    case "/":
                        if (num2 != 0.0)
                        {

                            res = num1 / num2;
                            
                            hist = (num1 + " / " + num2 + " = " + res);
                            History.Items.Add(hist);
                            memstore = res;
                            In.Clear();
                        }
                        else
                        {
                            In.Text = "error";
                        }
                        break;
                }
            }
            
           


        }

        private void MemClear_Click(object sender, EventArgs e)
        {
           
            memstore = 0.0;
            num1 = 0.0;
            num2 = 0.0;
            res = 0.0;
            In.Clear();
            return;
        }

        private void MemAdd_Click(object sender, EventArgs e)
        {
            num1 = Convert.ToDouble( In.Text);
            num2 = memstore;
            res= num1 + num2;
            memstore = res;
            memhist =" "+num1+" + "+num2+" = "+res+"";
            History.Items.Add(memhist);
            In.Clear();
            return;
        }

        private void MemSub_Click(object sender, EventArgs e)
        {

            num1 = Convert.ToDouble(In.Text);
            num2 = memstore;
            res = num1 - num2;
            memstore = res;
            memhist = " " + num1 + " - " + num2 + " = " + res + " ";
            History.Items.Add(memhist);
            In.Clear();
       
            return;
            
        }

        private void MemRem_Click(object sender, EventArgs e)
        {
            
            In.Text = memstore.ToString();
            return;
        }

        private void Clear_Click(object sender, EventArgs e)
        {
            In.Clear();
            num1 = 0; num2 = 0; 
        }
    }
}
