﻿
namespace calctest
{
    partial class Form1
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.period = new System.Windows.Forms.Button();
            this.zero = new System.Windows.Forms.Button();
            this.one = new System.Windows.Forms.Button();
            this.two = new System.Windows.Forms.Button();
            this.three = new System.Windows.Forms.Button();
            this.six = new System.Windows.Forms.Button();
            this.five = new System.Windows.Forms.Button();
            this.four = new System.Windows.Forms.Button();
            this.nine = new System.Windows.Forms.Button();
            this.eight = new System.Windows.Forms.Button();
            this.seven = new System.Windows.Forms.Button();
            this.Equal = new System.Windows.Forms.Button();
            this.Subtract = new System.Windows.Forms.Button();
            this.Add = new System.Windows.Forms.Button();
            this.Multiply = new System.Windows.Forms.Button();
            this.Divide = new System.Windows.Forms.Button();
            this.MemRem = new System.Windows.Forms.Button();
            this.MemSub = new System.Windows.Forms.Button();
            this.MemAdd = new System.Windows.Forms.Button();
            this.MemClear = new System.Windows.Forms.Button();
            this.History = new System.Windows.Forms.ListBox();
            this.label2 = new System.Windows.Forms.Label();
            this.In = new System.Windows.Forms.TextBox();
            this.Clear = new System.Windows.Forms.Button();
            this.SuspendLayout();
            // 
            // period
            // 
            this.period.BackColor = System.Drawing.SystemColors.ControlDark;
            this.period.Font = new System.Drawing.Font("Microsoft Sans Serif", 15.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.period.Location = new System.Drawing.Point(-2, 327);
            this.period.Name = "period";
            this.period.Size = new System.Drawing.Size(75, 52);
            this.period.TabIndex = 42;
            this.period.Text = ".";
            this.period.UseVisualStyleBackColor = false;
            this.period.Click += new System.EventHandler(this.period_Click);
            // 
            // zero
            // 
            this.zero.BackColor = System.Drawing.SystemColors.ControlDark;
            this.zero.Font = new System.Drawing.Font("Microsoft Sans Serif", 15.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.zero.Location = new System.Drawing.Point(79, 327);
            this.zero.Name = "zero";
            this.zero.Size = new System.Drawing.Size(75, 52);
            this.zero.TabIndex = 41;
            this.zero.Text = "0";
            this.zero.UseVisualStyleBackColor = false;
            this.zero.Click += new System.EventHandler(this.zero_Click);
            // 
            // one
            // 
            this.one.BackColor = System.Drawing.SystemColors.ControlDark;
            this.one.Font = new System.Drawing.Font("Microsoft Sans Serif", 15.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.one.Location = new System.Drawing.Point(-2, 269);
            this.one.Name = "one";
            this.one.Size = new System.Drawing.Size(75, 52);
            this.one.TabIndex = 40;
            this.one.Text = "1";
            this.one.UseVisualStyleBackColor = false;
            this.one.Click += new System.EventHandler(this.one_Click);
            // 
            // two
            // 
            this.two.BackColor = System.Drawing.SystemColors.ControlDark;
            this.two.Font = new System.Drawing.Font("Microsoft Sans Serif", 15.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.two.Location = new System.Drawing.Point(79, 269);
            this.two.Name = "two";
            this.two.Size = new System.Drawing.Size(75, 52);
            this.two.TabIndex = 39;
            this.two.Text = "2";
            this.two.UseVisualStyleBackColor = false;
            this.two.Click += new System.EventHandler(this.two_Click);
            // 
            // three
            // 
            this.three.BackColor = System.Drawing.SystemColors.ControlDark;
            this.three.Font = new System.Drawing.Font("Microsoft Sans Serif", 15.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.three.Location = new System.Drawing.Point(160, 269);
            this.three.Name = "three";
            this.three.Size = new System.Drawing.Size(75, 52);
            this.three.TabIndex = 38;
            this.three.Text = "3";
            this.three.UseVisualStyleBackColor = false;
            this.three.Click += new System.EventHandler(this.three_Click);
            // 
            // six
            // 
            this.six.BackColor = System.Drawing.SystemColors.ControlDark;
            this.six.Font = new System.Drawing.Font("Microsoft Sans Serif", 15.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.six.Location = new System.Drawing.Point(160, 211);
            this.six.Name = "six";
            this.six.Size = new System.Drawing.Size(75, 52);
            this.six.TabIndex = 37;
            this.six.Text = "6";
            this.six.UseVisualStyleBackColor = false;
            this.six.Click += new System.EventHandler(this.six_Click);
            // 
            // five
            // 
            this.five.BackColor = System.Drawing.SystemColors.ControlDark;
            this.five.Font = new System.Drawing.Font("Microsoft Sans Serif", 15.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.five.Location = new System.Drawing.Point(79, 211);
            this.five.Name = "five";
            this.five.Size = new System.Drawing.Size(75, 52);
            this.five.TabIndex = 36;
            this.five.Text = "5";
            this.five.UseVisualStyleBackColor = false;
            this.five.Click += new System.EventHandler(this.five_Click);
            // 
            // four
            // 
            this.four.BackColor = System.Drawing.SystemColors.ControlDark;
            this.four.Font = new System.Drawing.Font("Microsoft Sans Serif", 15.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.four.Location = new System.Drawing.Point(-2, 211);
            this.four.Name = "four";
            this.four.Size = new System.Drawing.Size(75, 52);
            this.four.TabIndex = 35;
            this.four.Text = "4";
            this.four.UseVisualStyleBackColor = false;
            this.four.Click += new System.EventHandler(this.four_Click);
            // 
            // nine
            // 
            this.nine.BackColor = System.Drawing.SystemColors.ControlDark;
            this.nine.Font = new System.Drawing.Font("Microsoft Sans Serif", 15.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.nine.Location = new System.Drawing.Point(160, 153);
            this.nine.Name = "nine";
            this.nine.Size = new System.Drawing.Size(75, 52);
            this.nine.TabIndex = 34;
            this.nine.Text = "9";
            this.nine.UseVisualStyleBackColor = false;
            this.nine.Click += new System.EventHandler(this.nine_Click);
            // 
            // eight
            // 
            this.eight.BackColor = System.Drawing.SystemColors.ControlDark;
            this.eight.Font = new System.Drawing.Font("Microsoft Sans Serif", 15.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.eight.Location = new System.Drawing.Point(79, 153);
            this.eight.Name = "eight";
            this.eight.Size = new System.Drawing.Size(75, 52);
            this.eight.TabIndex = 33;
            this.eight.Text = "8";
            this.eight.UseVisualStyleBackColor = false;
            this.eight.Click += new System.EventHandler(this.eight_Click);
            // 
            // seven
            // 
            this.seven.BackColor = System.Drawing.SystemColors.ControlDark;
            this.seven.Font = new System.Drawing.Font("Microsoft Sans Serif", 15.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.seven.Location = new System.Drawing.Point(-2, 153);
            this.seven.Name = "seven";
            this.seven.Size = new System.Drawing.Size(75, 52);
            this.seven.TabIndex = 32;
            this.seven.Text = "7";
            this.seven.UseVisualStyleBackColor = false;
            this.seven.Click += new System.EventHandler(this.seven_Click);
            // 
            // Equal
            // 
            this.Equal.BackColor = System.Drawing.SystemColors.ControlDark;
            this.Equal.Font = new System.Drawing.Font("Microsoft Sans Serif", 15.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Equal.Location = new System.Drawing.Point(-2, 381);
            this.Equal.Name = "Equal";
            this.Equal.Size = new System.Drawing.Size(318, 52);
            this.Equal.TabIndex = 31;
            this.Equal.Text = "=";
            this.Equal.UseVisualStyleBackColor = false;
            this.Equal.Click += new System.EventHandler(this.Equal_Click);
            // 
            // Subtract
            // 
            this.Subtract.Font = new System.Drawing.Font("Microsoft Sans Serif", 15.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Subtract.Location = new System.Drawing.Point(241, 327);
            this.Subtract.Name = "Subtract";
            this.Subtract.Size = new System.Drawing.Size(75, 52);
            this.Subtract.TabIndex = 30;
            this.Subtract.Text = "-";
            this.Subtract.UseVisualStyleBackColor = true;
            this.Subtract.Click += new System.EventHandler(this.Subtract_Click);
            // 
            // Add
            // 
            this.Add.Font = new System.Drawing.Font("Microsoft Sans Serif", 15.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Add.Location = new System.Drawing.Point(241, 269);
            this.Add.Name = "Add";
            this.Add.Size = new System.Drawing.Size(75, 52);
            this.Add.TabIndex = 29;
            this.Add.Text = "+";
            this.Add.UseVisualStyleBackColor = true;
            this.Add.Click += new System.EventHandler(this.Add_Click);
            // 
            // Multiply
            // 
            this.Multiply.Font = new System.Drawing.Font("Microsoft Sans Serif", 15.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Multiply.Location = new System.Drawing.Point(241, 211);
            this.Multiply.Name = "Multiply";
            this.Multiply.Size = new System.Drawing.Size(75, 52);
            this.Multiply.TabIndex = 28;
            this.Multiply.Text = "X";
            this.Multiply.UseVisualStyleBackColor = true;
            this.Multiply.Click += new System.EventHandler(this.Multiply_Click);
            // 
            // Divide
            // 
            this.Divide.Font = new System.Drawing.Font("Microsoft Sans Serif", 15.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Divide.Location = new System.Drawing.Point(241, 153);
            this.Divide.Name = "Divide";
            this.Divide.Size = new System.Drawing.Size(75, 52);
            this.Divide.TabIndex = 27;
            this.Divide.Text = "/";
            this.Divide.UseVisualStyleBackColor = true;
            this.Divide.Click += new System.EventHandler(this.Divide_Click);
            // 
            // MemRem
            // 
            this.MemRem.Font = new System.Drawing.Font("Microsoft Sans Serif", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.MemRem.Location = new System.Drawing.Point(241, 95);
            this.MemRem.Name = "MemRem";
            this.MemRem.Size = new System.Drawing.Size(75, 52);
            this.MemRem.TabIndex = 26;
            this.MemRem.Text = "MemR";
            this.MemRem.UseVisualStyleBackColor = true;
            this.MemRem.Click += new System.EventHandler(this.MemRem_Click);
            // 
            // MemSub
            // 
            this.MemSub.Font = new System.Drawing.Font("Microsoft Sans Serif", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.MemSub.Location = new System.Drawing.Point(160, 95);
            this.MemSub.Name = "MemSub";
            this.MemSub.Size = new System.Drawing.Size(75, 52);
            this.MemSub.TabIndex = 25;
            this.MemSub.Text = "Mem-";
            this.MemSub.UseVisualStyleBackColor = true;
            this.MemSub.Click += new System.EventHandler(this.MemSub_Click);
            // 
            // MemAdd
            // 
            this.MemAdd.Font = new System.Drawing.Font("Microsoft Sans Serif", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.MemAdd.Location = new System.Drawing.Point(79, 95);
            this.MemAdd.Name = "MemAdd";
            this.MemAdd.Size = new System.Drawing.Size(75, 52);
            this.MemAdd.TabIndex = 24;
            this.MemAdd.Text = "Mem+";
            this.MemAdd.UseVisualStyleBackColor = true;
            this.MemAdd.Click += new System.EventHandler(this.MemAdd_Click);
            // 
            // MemClear
            // 
            this.MemClear.Font = new System.Drawing.Font("Microsoft Sans Serif", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.MemClear.Location = new System.Drawing.Point(-2, 95);
            this.MemClear.Name = "MemClear";
            this.MemClear.Size = new System.Drawing.Size(75, 52);
            this.MemClear.TabIndex = 23;
            this.MemClear.Text = "MemC";
            this.MemClear.UseVisualStyleBackColor = true;
            this.MemClear.Click += new System.EventHandler(this.MemClear_Click);
            // 
            // History
            // 
            this.History.BackColor = System.Drawing.SystemColors.InactiveCaption;
            this.History.FormattingEnabled = true;
            this.History.Location = new System.Drawing.Point(323, 26);
            this.History.Name = "History";
            this.History.Size = new System.Drawing.Size(207, 407);
            this.History.TabIndex = 43;
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Location = new System.Drawing.Point(402, 9);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(39, 13);
            this.label2.TabIndex = 44;
            this.label2.Text = "History";
            // 
            // In
            // 
            this.In.BackColor = System.Drawing.SystemColors.InactiveCaption;
            this.In.BorderStyle = System.Windows.Forms.BorderStyle.None;
            this.In.Font = new System.Drawing.Font("Microsoft Sans Serif", 25.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.In.Location = new System.Drawing.Point(-2, 43);
            this.In.Name = "In";
            this.In.Size = new System.Drawing.Size(319, 39);
            this.In.TabIndex = 45;
            this.In.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
            // 
            // Clear
            // 
            this.Clear.BackColor = System.Drawing.SystemColors.ControlDark;
            this.Clear.Font = new System.Drawing.Font("Microsoft Sans Serif", 14.25F);
            this.Clear.Location = new System.Drawing.Point(160, 327);
            this.Clear.Name = "Clear";
            this.Clear.Size = new System.Drawing.Size(75, 52);
            this.Clear.TabIndex = 46;
            this.Clear.Text = "Clear";
            this.Clear.UseVisualStyleBackColor = false;
            this.Clear.Click += new System.EventHandler(this.Clear_Click);
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.SystemColors.InactiveCaption;
            this.ClientSize = new System.Drawing.Size(528, 431);
            this.Controls.Add(this.Clear);
            this.Controls.Add(this.In);
            this.Controls.Add(this.label2);
            this.Controls.Add(this.History);
            this.Controls.Add(this.period);
            this.Controls.Add(this.zero);
            this.Controls.Add(this.one);
            this.Controls.Add(this.two);
            this.Controls.Add(this.three);
            this.Controls.Add(this.six);
            this.Controls.Add(this.five);
            this.Controls.Add(this.four);
            this.Controls.Add(this.nine);
            this.Controls.Add(this.eight);
            this.Controls.Add(this.seven);
            this.Controls.Add(this.Equal);
            this.Controls.Add(this.Subtract);
            this.Controls.Add(this.Add);
            this.Controls.Add(this.Multiply);
            this.Controls.Add(this.Divide);
            this.Controls.Add(this.MemRem);
            this.Controls.Add(this.MemSub);
            this.Controls.Add(this.MemAdd);
            this.Controls.Add(this.MemClear);
            this.Name = "Form1";
            this.Text = "Calculator";
            this.Load += new System.EventHandler(this.Form1_Load);
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Button period;
        private System.Windows.Forms.Button zero;
        private System.Windows.Forms.Button one;
        private System.Windows.Forms.Button two;
        private System.Windows.Forms.Button three;
        private System.Windows.Forms.Button six;
        private System.Windows.Forms.Button five;
        private System.Windows.Forms.Button four;
        private System.Windows.Forms.Button nine;
        private System.Windows.Forms.Button eight;
        private System.Windows.Forms.Button seven;
        private System.Windows.Forms.Button Equal;
        private System.Windows.Forms.Button Subtract;
        private System.Windows.Forms.Button Add;
        private System.Windows.Forms.Button Multiply;
        private System.Windows.Forms.Button Divide;
        private System.Windows.Forms.Button MemRem;
        private System.Windows.Forms.Button MemSub;
        private System.Windows.Forms.Button MemAdd;
        private System.Windows.Forms.Button MemClear;
        private System.Windows.Forms.ListBox History;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.TextBox In;
        private System.Windows.Forms.Button Clear;
    }
}

