﻿using System;
using System.IO;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Runtime.Serialization.Formatters.Binary;
using System.Threading.Tasks;

namespace calctest
{
    public class LastValTest
    {
        public string FN = "LastVal.Dat";
        public void Serialize(LastValMem memdata)
        {
            Stream Mem = File.OpenWrite(FN);
            var Formatter = new BinaryFormatter();
            Formatter.Serialize(Mem, memdata);
            Mem.Flush();
            Mem.Close();
            Mem.Dispose();
        }
        public LastValMem Deserialize() 
        {
            var formatter = new BinaryFormatter();
            var fileS = File.Open(FN, FileMode.Open);
            var obj = formatter.Deserialize(fileS);
            var memory = (LastValMem)obj;
            fileS.Flush();
            fileS.Close();
            fileS.Dispose();
            return memory;
        }
    }
}
